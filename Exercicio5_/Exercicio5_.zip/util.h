#ifndef UTIL_H
#define UTIL_H


#define tam 70


#endif //UTIL_H