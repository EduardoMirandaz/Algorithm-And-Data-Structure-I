#ifndef READINPUT_H
#define READINPUT_H

int readIntInput();

#endif 